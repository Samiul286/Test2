{{-- resources/views/super-admin/auth/login.blade.php --}}
@extends('layouts.auth')

@section('title', 'Super Admin Login')
@section('auth_subtitle', 'Central Super Admin Panel')

@section('content')
    <form method="POST" action="{{ route('super-admin.login.post') }}">
        @csrf

        @if($errors->any())
            <div class="alert alert-danger">
                <i class="fas fa-exclamation-circle"></i>
                <span>{{ $errors->first() }}</span>
            </div>
        @endif

        <div class="form-group">
            <label>ইমেইল</label>
            <div class="input-wrap">
                <i class="fas fa-envelope"></i>
                <input type="email" name="email"
                    class="form-control"
                    placeholder="superadmin@example.com"
                    value="{{ old('email') }}"
                    autocomplete="email" autofocus required>
            </div>
        </div>

        <div class="form-group">
            <label>পাসওয়ার্ড</label>
            <div class="input-wrap">
                <i class="fas fa-lock"></i>
                <input type="password" name="password"
                    class="form-control"
                    placeholder="••••••••"
                    autocomplete="current-password" required>
            </div>
        </div>

        <div class="remember-row">
            <input type="checkbox" name="remember" id="remember" value="1">
            <label for="remember" style="text-transform:none; font-weight:400; margin:0;">আমাকে মনে রাখো</label>
        </div>

        <button type="submit" class="btn-login">
            <i class="fas fa-user-shield"></i> লগইন করুন
        </button>
    </form>

    <div class="hint-box">
        <strong><i class="fas fa-shield-alt"></i> Super Admin Panel</strong>
        শুধুমাত্র অনুমোদিত সুপার অ্যাডমিন এখানে লগইন করতে পারবেন।
    </div>
@endsection
