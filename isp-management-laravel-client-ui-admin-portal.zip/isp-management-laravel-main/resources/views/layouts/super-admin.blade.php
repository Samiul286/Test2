{{-- resources/views/layouts/super-admin.blade.php --}}
{{-- Passthrough: the central Super Admin portal now shares the exact same
     client-portal design system as layouts.app. The layout detects the
     'super_admin' guard automatically and swaps the user pill, profile
     link, logout route and bell/visibility accordingly. Sections defined
     by super-admin/* views (page_title / page_actions / page_content /
     content_header / content / extra_css / css / extra_js / js) all
     propagate straight through to layouts.app. --}}
@extends('layouts.app')
