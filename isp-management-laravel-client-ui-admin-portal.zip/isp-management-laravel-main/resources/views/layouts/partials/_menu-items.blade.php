{{-- resources/views/layouts/partials/_menu-items.blade.php --}}
{{-- Recursive sidebar menu renderer — reads config('adminlte.menu'),
     honours 'can' gates exactly like AdminLTE's GateFilter did,
     marks active items and auto-opens the matching groups. --}}

@foreach($items as $item)
    @if(!menuAllowed($item)) @continue @endif

    @if(isset($item['header']))
        <div class="a-nav-section">{{ $item['header'] }}</div>

    @elseif(!empty($item['submenu']))
        @php
            $subs = array_values(array_filter($item['submenu'], 'menuAllowed'));
        @endphp
        @if(count($subs))
            @php $gActive = groupActive($item); @endphp
            <div class="a-nav-group {{ $gActive ? 'open' : '' }}">
                <button type="button" class="a-nav-item a-group-toggle">
                    <i class="{{ $item['icon'] ?? 'far fa-circle' }}"></i>
                    <span class="a-nav-text">{{ $item['text'] }}</span>
                    <i class="fas fa-chevron-down a-chevron"></i>
                </button>
                <div class="a-submenu">
                    <div class="a-submenu-inner">
                        @include('layouts.partials._menu-items', ['items' => $subs])
                    </div>
                </div>
            </div>
        @endif

    @else
        <a href="{{ menuHref($item) }}" class="a-nav-item {{ menuActive($item) ? 'active' : '' }}">
            <i class="{{ $item['icon'] ?? 'far fa-circle' }}"></i>
            <span class="a-nav-text">{{ $item['text'] }}</span>
        </a>
    @endif
@endforeach
