{{-- resources/views/layouts/app.blade.php --}}
{{-- ════════════════════════════════════════════════════════════════════
     ISP Admin / Staff Portal — Client Self-Service Portal Design System
     Same UI/UX as resources/views/client/layout.blade.php
     (teal #00c897 + navy #1a1f36, radius-12 cards, Segoe UI, FA 6.4)
     Fully standalone — no AdminLTE dependency. Bootstrap 4 is kept ONLY
     for grid / modals / dropdowns of the 150+ existing pages, and every
     Bootstrap component is re-skinned to the client-portal look.
     Yields the same sections the old AdminLTE wrapper did:
       page_title / page_actions / page_content / content_header /
       content / title / extra_css / css / extra_js / js / @stack('css'|'js')
     ════════════════════════════════════════════════════════════════════ --}}

@php
    // ── Active guard: normal admin/staff ('web') OR central Super Admin ──
    $user  = Auth::user();
    $guard = 'web';
    if (!$user && Auth::guard('super_admin')->check()) {
        $user  = Auth::guard('super_admin')->user();
        $guard = 'super_admin';
    }

    // ── Company name (tenant settings, falls back on central domain) ──
    try {
        $companyName = \App\Models\Setting::get('company_name', config('adminlte.title', 'ISP Management'));
    } catch (\Throwable $e) {
        $companyName = config('adminlte.title', 'ISP Management');
    }

    // ── Menu helpers (guarded against double definition) ──
    if (!function_exists('menuHref')) {
        function menuHref($item) {
            if (isset($item['route'])) {
                try { return route($item['route']); } catch (\Throwable $e) { return '#'; }
            }
            if (isset($item['url']))  { return url($item['url']); }
            return '#';
        }
    }
    if (!function_exists('menuAllowed')) {
        function menuAllowed($item) {
            if (!isset($item['can'])) return true;
            try {
                $can = $item['can'];
                if (is_array($can)) {
                    foreach ($can as $ability) { if (\Illuminate\Support\Facades\Gate::allows($ability)) return true; }
                    return false;
                }
                return \Illuminate\Support\Facades\Gate::allows($can);
            } catch (\Throwable $e) {
                return false;
            }
        }
    }
    if (!function_exists('menuActive')) {
        function menuActive($item) {
            if (!isset($item['url']) || $item['url'] === '#' || $item['url'] === '') return false;
            $path    = trim($item['url'], '/');
            $current = trim(request()->path(), '/');
            if ($path === '' || $current === '') return false;
            if ($current === $path) return true;
            return \Illuminate\Support\Str::startsWith($current, $path . '/');
        }
    }
    if (!function_exists('groupActive')) {
        function groupActive($item) {
            if (menuActive($item)) return true;
            if (!empty($item['submenu'])) {
                foreach ($item['submenu'] as $sub) { if (groupActive($sub)) return true; }
            }
            return false;
        }
    }

    $menuItems = config('adminlte.menu', []);
    $initials  = strtoupper(substr(trim($user->name ?? $user->email ?? 'U'), 0, 2));
    $homeUrl   = $guard === 'super_admin' ? url('super-admin') : url('dashboard');
@endphp

<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>@yield('title', 'Dashboard') — {{ $companyName }}</title>

    {{-- Font Awesome 6.4 — same version as the Client Portal --}}
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    {{-- Bootstrap 4.6 — grid / modals / dropdowns for existing pages --}}
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">

    {{-- Toastr --}}
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">

    {{-- Select2 --}}
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />

    {{-- Page-level styles FIRST, so the design system below wins ties --}}
    @yield('extra_css')
    @yield('css')
    @stack('css')

    <style>
        /* ══════════════════════════════════════════════════════════════
           [1] BASE — identical tokens to client/layout.blade.php
           ══════════════════════════════════════════════════════════════ */
        * { box-sizing: border-box; }
        body {
            font-family: 'Segoe UI', Tahoma, sans-serif;
            background: #f4f6f9;
            color: #333;
            font-size: 13.5px;
            min-height: 100vh;
            margin: 0;
        }
        h1, h2, h3, h4, h5, h6 { color: #1a1f36; font-weight: 600; }
        a { color: #00a583; }
        a:hover { color: #00b386; text-decoration: none; }
        hr { border-color: #f0f2f7; }
        ::selection { background: #b3ecd9; }

        /* ══════════════════════════════════════════════════════════════
           [2] TOPBAR — navy #1a1f36, 56px, fixed
           ══════════════════════════════════════════════════════════════ */
        .a-topbar {
            background: #1a1f36;
            color: #fff;
            height: 56px;
            display: flex; align-items: center; justify-content: space-between;
            padding: 0 20px;
            position: fixed; top: 0; left: 0; right: 0; z-index: 200;
        }
        .a-topbar-left { display: flex; align-items: center; gap: 12px; min-width: 0; }
        .a-brand {
            display: flex; align-items: center; gap: 10px;
            font-size: 18px; font-weight: 700; color: #fff; text-decoration: none;
            white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 300px;
        }
        .a-brand:hover { color: #fff; }
        .a-logo-box {
            width: 36px; height: 36px; background: #00c897;
            border-radius: 8px; display: flex; align-items: center; justify-content: center;
            font-size: 16px; font-weight: 800; color: #fff; flex-shrink: 0;
        }
        .a-hamburger {
            background: none; border: none; color: #fff; font-size: 20px;
            cursor: pointer; display: none; padding: 4px 8px; line-height: 1;
        }
        .a-topbar-right { display: flex; align-items: center; gap: 6px; }
        .a-topbar-right li { list-style: none; }

        /* bell + language switcher recolored for the dark topbar */
        .a-topbar .notif-bell-btn,
        .a-topbar .lang-switch-btn { color: rgba(255,255,255,.75); padding: 8px 10px; }
        .a-topbar .notif-bell-btn:hover,
        .a-topbar .lang-switch-btn:hover { color: #fff; }
        .a-topbar .notif-badge { top: 2px; }

        /* ══════════════════════════════════════════════════════════════
           [3] USER PILL + DROPDOWN — client-portal style
           ══════════════════════════════════════════════════════════════ */
        .a-user-pill {
            display: flex; align-items: center; gap: 8px;
            background: rgba(255,255,255,.1); border-radius: 999px;
            padding: 5px 14px 5px 5px; cursor: pointer;
            position: relative; margin-left: 6px;
        }
        .a-user-pill:hover { background: rgba(255,255,255,.16); }
        .a-user-avatar {
            width: 30px; height: 30px; background: #00c897;
            border-radius: 50%; display: flex; align-items: center; justify-content: center;
            font-size: 12px; font-weight: 700; color: #fff; flex-shrink: 0;
        }
        .a-user-pill .a-user-name { font-size: 13px; color: #fff; max-width: 160px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
        .a-user-pill > .a-caret { font-size: 10px; color: rgba(255,255,255,.55); margin-left: 2px; }
        .a-user-dropdown {
            display: none;
            position: absolute; top: calc(100% + 10px); right: 0;
            background: #fff; border-radius: 12px;
            box-shadow: 0 8px 30px rgba(0,0,0,.15);
            min-width: 230px; z-index: 9999; overflow: hidden; border: 1px solid #eef0f5;
        }
        .a-user-dropdown.open { display: block; }
        .a-dd-header { display: flex; align-items: center; gap: 12px; padding: 16px; background: #f8f9fc; }
        .a-dd-avatar {
            width: 42px; height: 42px; background: #1a1f36;
            border-radius: 50%; display: flex; align-items: center; justify-content: center;
            font-size: 16px; font-weight: 700; color: #00c897; flex-shrink: 0;
        }
        .a-dd-name { font-size: 14px; font-weight: 600; color: #1a1f36; word-break: break-word; }
        .a-dd-sub  { font-size: 12px; color: #888; margin-top: 2px; }
        .a-dd-divider { height: 1px; background: #f0f2f7; }
        .a-dd-item {
            display: flex; align-items: center; gap: 10px;
            padding: 11px 16px; font-size: 13px; color: #444;
            text-decoration: none; transition: background .15s; width: 100%;
        }
        .a-dd-item i { width: 16px; text-align: center; color: #aaa; font-size: 14px; }
        .a-dd-item:hover { background: #f0faf7; color: #00c897; }
        .a-dd-item:hover i { color: #00c897; }
        .a-dd-item.a-dd-logout { color: #e74c3c; background: none; border: none; cursor: pointer; text-align: left; }
        .a-dd-item.a-dd-logout i { color: #e74c3c; }
        .a-dd-item.a-dd-logout:hover { background: #fff0f0; color: #c0392b; }

        /* ══════════════════════════════════════════════════════════════
           [4] SIDEBAR — white, 200px, teal 3px active border
           ══════════════════════════════════════════════════════════════ */
        .a-sidebar {
            width: 200px; background: #fff; border-right: 1px solid #e8eaf0;
            position: fixed; top: 56px; left: 0; bottom: 0;
            overflow-y: auto; overflow-x: hidden; z-index: 100;
            transition: transform .25s ease;
            display: flex; flex-direction: column;
        }
        .a-sidebar::-webkit-scrollbar { width: 5px; }
        .a-sidebar::-webkit-scrollbar-track { background: transparent; }
        .a-sidebar::-webkit-scrollbar-thumb { background: #e0e4ef; border-radius: 4px; }
        .a-side-nav { padding: 12px 0 8px; flex: 1 1 auto; }

        .a-nav-section {
            padding: 14px 20px 6px; font-size: 11px; font-weight: 700;
            letter-spacing: 1px; text-transform: uppercase; color: #aaa;
            white-space: nowrap;
        }
        .a-nav-item {
            display: flex; align-items: center; gap: 10px;
            width: 100%;
            padding: 11px 20px; font-size: 13.5px; color: #555;
            text-decoration: none; border-left: 3px solid transparent;
            background: none; border-top: none; border-right: none; border-bottom: none;
            cursor: pointer; text-align: left;
            transition: all .15s; font-family: inherit;
        }
        .a-nav-item > i:not(.a-chevron) {
            width: 18px; text-align: center; font-size: 15px;
            color: inherit !important; flex-shrink: 0;
        }
        .a-nav-item .a-nav-text { flex: 1; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
        .a-nav-item:hover { background: #f0faf7; color: #00c897; }
        .a-nav-item.active { background: #f0faf7; color: #00c897; border-left-color: #00c897; font-weight: 600; }

        .a-chevron { font-size: 10px; color: #aaa; transition: transform .2s; flex-shrink: 0; }
        .a-nav-group.open > .a-group-toggle .a-chevron { transform: rotate(180deg); }
        .a-group-toggle .a-chevron { margin-left: auto; }

        .a-submenu { display: grid; grid-template-rows: 0fr; transition: grid-template-rows .25s ease; }
        .a-nav-group.open > .a-submenu { grid-template-rows: 1fr; }
        .a-submenu-inner { overflow: hidden; min-height: 0; }
        .a-sub-item {
            display: flex; align-items: center; gap: 10px;
            padding: 9px 14px 9px 31px; font-size: 13px; color: #666;
            text-decoration: none; border-left: 3px solid transparent;
            transition: all .15s;
        }
        .a-sub-item > i { width: 16px; text-align: center; font-size: 12px; color: inherit !important; flex-shrink: 0; opacity: .8; }
        .a-sub-item .a-nav-text { flex: 1; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
        .a-sub-item:hover { background: #f0faf7; color: #00c897; }
        .a-sub-item.active { background: #f0faf7; color: #00c897; border-left-color: #00c897; font-weight: 600; }
        .a-submenu .a-submenu .a-sub-item { padding-left: 44px; font-size: 12.5px; }

        .a-nav-divider { height: 1px; background: #f0f0f0; margin: 8px 0; }
        .a-side-foot { padding: 8px 0 12px; }

        /* ══════════════════════════════════════════════════════════════
           [5] PAGE CONTENT / HEADING / FOOTER
           ══════════════════════════════════════════════════════════════ */
        .a-main { margin-top: 56px; min-height: calc(100vh - 56px); display: flex; flex-direction: column; }
        .a-page-content { margin-left: 200px; padding: 24px; flex: 1 1 auto; width: 100%; }

        .a-page-head {
            display: flex; align-items: center; justify-content: space-between;
            gap: 12px; flex-wrap: wrap; margin-bottom: 20px;
        }
        .a-page-title {
            font-size: 22px; font-weight: 600; color: #1a1f36;
            margin: 0; line-height: 1.3;
        }
        .a-page-head h1, .a-page-head h2, .a-page-head h3, .a-page-head h4 {
            font-size: 22px; font-weight: 600; color: #1a1f36;
            margin: 0; line-height: 1.3;
        }
        .a-page-head .text-primary { color: #00a583 !important; }
        .a-page-head small.text-muted { display: inline-block; margin-top: 2px; font-size: 12px; }
        .a-page-actions { display: flex; align-items: center; gap: 8px; flex-wrap: wrap; }
        .a-page-actions .dropdown-menu-right { right: 0; left: auto; }

        .a-footer {
            text-align: center; padding: 16px; font-size: 12px; color: #aaa;
            border-top: 1px solid #eef0f5; margin-left: 200px; background: #fff;
        }
        .a-footer a { color: #00c897; text-decoration: none; }

        .a-backdrop {
            position: fixed; inset: 0; background: rgba(26,31,54,.5);
            z-index: 90; opacity: 0; pointer-events: none; transition: opacity .25s;
        }
        .a-backdrop.show { opacity: 1; pointer-events: auto; }

        .a-table-wrap { overflow-x: auto; -webkit-overflow-scrolling: touch; }
        /* ══════════════════════════════════════════════════════════════
           [6] CARDS — radius 12, #eef0f5 border, uppercase headers
           ══════════════════════════════════════════════════════════════ */
        .card {
            background: #fff !important;
            border-radius: 12px !important;
            border: 1px solid #eef0f5 !important;
            box-shadow: none !important;
            margin-bottom: 20px;
        }
        .card > .card-header:first-child,
        .card > :first-child { border-radius: 12px 12px 0 0; }
        .card > :last-child  { border-radius: 0 0 12px 12px; }
        .card > :only-child  { border-radius: 12px; }
        .card-header {
            background: #fff !important;
            border-bottom: 1px solid #f0f2f7 !important;
            padding: 14px 20px !important;
            display: flex; align-items: center; gap: 10px;
        }
        .card-title {
            font-size: 13px !important; font-weight: 600 !important;
            color: #1a1f36 !important; text-transform: uppercase; letter-spacing: .5px;
            margin: 0 !important; display: flex; align-items: center; gap: 8px; line-height: 1.4;
        }
        .card-title i { color: #00c897; font-size: 13px; }
        .card-body { padding: 20px !important; }
        .card-body.p-0 { padding: 0 !important; }
        .card-footer {
            background: #fafbfd !important; border-top: 1px solid #f0f2f7 !important;
            padding: 12px 20px !important; border-radius: 0 0 12px 12px;
        }
        .card-tools { margin-left: auto; display: flex; align-items: center; gap: 6px; opacity: 1 !important; }
        .card .btn-tool { color: #aaa; box-shadow: none; padding: 2px 6px; }
        .card .btn-tool:hover { color: #00c897; }

        /* AdminLTE colored card variants (used across HR / inventory / settings) */
        .card-primary   > .card-header { background: #00c897 !important; color: #fff !important; border-bottom: 1px solid #00b386 !important; }
        .card-secondary > .card-header { background: #95a5a6 !important; color: #fff !important; border-bottom: 1px solid #87999a !important; }
        .card-success   > .card-header { background: #27ae60 !important; color: #fff !important; border-bottom: 1px solid #219653 !important; }
        .card-info      > .card-header { background: #3a7bd5 !important; color: #fff !important; border-bottom: 1px solid #3268b8 !important; }
        .card-warning   > .card-header { background: #e67e22 !important; color: #fff !important; border-bottom: 1px solid #cc6f1d !important; }
        .card-danger    > .card-header { background: #e74c3c !important; color: #fff !important; border-bottom: 1px solid #d33727 !important; }
        .card-primary   > .card-header .card-title,
        .card-secondary > .card-header .card-title,
        .card-success   > .card-header .card-title,
        .card-info      > .card-header .card-title,
        .card-warning   > .card-header .card-title,
        .card-danger    > .card-header .card-title { color: #fff !important; }
        .card-primary   > .card-header .card-title i, .card-secondary > .card-header .card-title i,
        .card-success   > .card-header .card-title i, .card-info      > .card-header .card-title i,
        .card-warning   > .card-header .card-title i, .card-danger    > .card-header .card-title i { color: #fff; }
        .card-outline > .card-header { background: #fff !important; border-bottom: 1px solid #f0f2f7 !important; box-shadow: inset 0 -2px 0 #00c897; }
        .card-outline.card-primary   > .card-header .card-title { color: #00c897 !important; }
        .card-outline.card-success   > .card-header .card-title { color: #27ae60 !important; }
        .card-outline.card-info      > .card-header .card-title { color: #3a7bd5 !important; }
        .card-outline.card-warning   > .card-header .card-title { color: #e67e22 !important; }
        .card-outline.card-danger    > .card-header .card-title { color: #e74c3c !important; }

        /* ══════════════════════════════════════════════════════════════
           [7] STAT CARDS — .cust-stat-card (22 pages), .small-box,
               .info-box → white card + 52px circular icon chip
           ══════════════════════════════════════════════════════════════ */
        .cust-stat-card {
            position: relative;
            background: #fff !important;
            border: 1px solid #eef0f5 !important;
            border-radius: 12px !important;
            box-shadow: none !important;
            height: auto !important; min-height: 88px;
            padding: 18px 20px !important;
            display: flex !important; align-items: center !important;
            justify-content: flex-start !important; gap: 16px;
            margin-bottom: 16px !important;
            overflow: visible !important;
            transition: box-shadow .2s;
        }
        .cust-stat-card:hover { box-shadow: 0 4px 16px rgba(26,31,54,.07) !important; }
        .cust-stat-card .sc-left { flex: 1; min-width: 0; }
        .cust-stat-card .sc-label {
            font-size: 11px !important; font-weight: 600 !important;
            color: #888 !important; text-transform: uppercase; letter-spacing: .5px;
            margin-bottom: 4px !important; display: flex; align-items: center; gap: 6px;
            white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
        }
        .cust-stat-card .sc-label i { color: inherit !important; font-size: 11px !important; }
        .cust-stat-card .sc-value {
            font-size: 24px !important; font-weight: 700 !important;
            color: #1a1f36 !important; line-height: 1 !important;
            word-break: break-word;
        }
        .cust-stat-card .sc-icon {
            order: -1;
            width: 52px; height: 52px; min-width: 52px;
            border-radius: 50% !important;
            display: flex; align-items: center; justify-content: center;
            font-size: 20px !important;
            background: #e0faf3; color: #00c897;
            transition: transform .2s;
        }
        .cust-stat-card:hover .sc-icon { transform: scale(1.06); }
        .cust-stat-card .sc-link { z-index: 2; }
        .stats-loading { opacity: .45; pointer-events: none; }

        /* chip colors (assigned by JS from the original card color) */
        .cust-stat-card.sc-teal   .sc-icon { background: #e0faf3; color: #00c897; }
        .cust-stat-card.sc-blue   .sc-icon { background: #e0eeff; color: #3a7bd5; }
        .cust-stat-card.sc-green  .sc-icon { background: #e8fbe8; color: #27ae60; }
        .cust-stat-card.sc-orange .sc-icon { background: #fff3e0; color: #e67e22; }
        .cust-stat-card.sc-red    .sc-icon { background: #fff0f0; color: #e74c3c; }
        .cust-stat-card.sc-purple .sc-icon { background: #f1ebfa; color: #8e44ad; }
        .cust-stat-card.sc-gray   .sc-icon { background: #f0f2f5; color: #7f8c8d; }

        /* AdminLTE .small-box */
        .small-box {
            position: relative;
            background: #fff !important;
            border: 1px solid #eef0f5 !important;
            border-radius: 12px !important;
            box-shadow: none !important;
            margin-bottom: 16px !important;
            display: flex !important; align-items: center !important;
            padding: 18px 20px !important; min-height: 88px;
            overflow: hidden;
        }
        .small-box .inner { padding: 0 !important; flex: 1; min-width: 0; z-index: 1; color: #1a1f36; }
        .small-box .inner h3 {
            font-size: 24px !important; font-weight: 700 !important;
            color: #1a1f36 !important; margin: 0 0 2px !important; line-height: 1;
        }
        .small-box .inner p {
            font-size: 11px !important; color: #888 !important; font-weight: 600 !important;
            text-transform: uppercase; letter-spacing: .5px; margin: 0; white-space: nowrap;
            overflow: hidden; text-overflow: ellipsis;
        }
        .small-box > .icon {
            order: -1;
            width: 52px; height: 52px; min-width: 52px;
            margin: 0 16px 0 0;
            border-radius: 50% !important;
            display: flex; align-items: center; justify-content: center;
            font-size: 20px !important;
            background: #e0faf3; color: #00c897;
            position: static !important; z-index: 1;
            transition: all .3s;
        }
        .small-box:hover > .icon { transform: scale(1.06); }
        .small-box .small-box-footer {
            position: static; background: transparent !important; color: #3a7bd5;
            padding: 10px 0 0; font-size: 12px; display: block;
        }
        .small-box .small-box-footer:hover { color: #00c897; }
        .small-box.sb-teal   > .icon { background: #e0faf3; color: #00c897; }
        .small-box.sb-blue   > .icon { background: #e0eeff; color: #3a7bd5; }
        .small-box.sb-green  > .icon { background: #e8fbe8; color: #27ae60; }
        .small-box.sb-orange > .icon { background: #fff3e0; color: #e67e22; }
        .small-box.sb-red    > .icon { background: #fff0f0; color: #e74c3c; }
        .small-box.sb-purple > .icon { background: #f1ebfa; color: #8e44ad; }
        .small-box.sb-gray   > .icon { background: #f0f2f5; color: #7f8c8d; }

        /* AdminLTE .info-box */
        .info-box {
            position: relative;
            background: #fff !important;
            border: 1px solid #eef0f5 !important;
            border-radius: 12px !important;
            box-shadow: none !important;
            padding: 16px 18px !important; margin-bottom: 16px !important;
            display: flex !important; align-items: center !important; gap: 14px;
            min-height: 84px;
        }
        .info-box-icon {
            width: 52px; height: 52px; min-width: 52px;
            border-radius: 50% !important;
            display: flex; align-items: center; justify-content: center;
            font-size: 20px !important;
            background: #e0faf3 !important; color: #00c897 !important;
        }
        .info-box-content { min-width: 0; }
        .info-box-text {
            font-size: 11px; color: #888; font-weight: 600;
            text-transform: uppercase; letter-spacing: .5px; display: block;
            white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
        }
        .info-box-number { font-size: 22px; font-weight: 700; color: #1a1f36; display: block; }
        .info-box.ib-teal   .info-box-icon { background: #e0faf3 !important; color: #00c897 !important; }
        .info-box.ib-blue   .info-box-icon { background: #e0eeff !important; color: #3a7bd5 !important; }
        .info-box.ib-green  .info-box-icon { background: #e8fbe8 !important; color: #27ae60 !important; }
        .info-box.ib-orange .info-box-icon { background: #fff3e0 !important; color: #e67e22 !important; }
        .info-box.ib-red    .info-box-icon { background: #fff0f0 !important; color: #e74c3c !important; }
        .info-box.ib-purple .info-box-icon { background: #f1ebfa !important; color: #8e44ad !important; }
        .info-box.ib-gray   .info-box-icon { background: #f0f2f5 !important; color: #7f8c8d !important; }

        /* ══════════════════════════════════════════════════════════════
           [8] TABLES — client .data-table look
           ══════════════════════════════════════════════════════════════ */
        .table { color: #444; font-size: 13px; }
        .table thead th, .table thead td {
            background: #f8f9fc !important;
            border-bottom: 2px solid #eef0f5 !important;
            border-top: none !important;
            font-size: 12px; font-weight: 600; color: #555;
            text-transform: uppercase; letter-spacing: .4px;
            padding: 10px 14px; white-space: nowrap;
        }
        .table td {
            padding: 11px 14px; border-top: none;
            border-bottom: 1px solid #f4f6f9; color: #444; vertical-align: middle;
        }
        .table th { vertical-align: middle; }
        .table tbody tr:last-child td { border-bottom: none; }
        .table tbody tr:hover > td { background: #fafbfd; }
        .table-striped tbody tr:nth-of-type(odd) { background-color: transparent; }
        .table-striped tbody tr:nth-of-type(odd):hover { background-color: #fafbfd; }
        .table-hover tbody tr:hover { color: #444; }
        .thead-dark th, .thead-dark td {
            background: #f8f9fc !important; color: #555 !important;
            border-bottom: 2px solid #eef0f5 !important; border-top: none !important;
        }
        .table-sm td, .table-sm th { padding: 9px 12px; }
        .table-bordered { border: none !important; }
        .table-bordered td, .table-bordered th { border: 1px solid #f0f2f7 !important; }
        .table-dark { color: #444; background: #fff; }

        /* ══════════════════════════════════════════════════════════════
           [9] BADGES — pill, 11px/600
           ══════════════════════════════════════════════════════════════ */
        .badge {
            display: inline-block; padding: 3px 10px; border-radius: 999px !important;
            font-size: 11px; font-weight: 600; line-height: 1.5;
        }
        .badge-primary   { background: #00c897; color: #fff; }
        .badge-success   { background: #00c897; color: #fff; }
        .badge-danger    { background: #e74c3c; color: #fff; }
        .badge-warning   { background: #f39c12; color: #fff; }
        .badge-info      { background: #3a7bd5; color: #fff; }
        .badge-secondary { background: #95a5a6; color: #fff; }
        .badge-dark      { background: #1a1f36; color: #fff; }
        .badge-light     { background: #f0f2f5; color: #666; }
        .badge-active    { background: #00c897; color: #fff; }
        .badge-inactive  { background: #95a5a6; color: #fff; }
        .badge-suspended { background: #f39c12; color: #fff; }
        .badge-expired   { background: #e74c3c; color: #fff; }
        .badge-pill      { border-radius: 999px !important; }

        /* ══════════════════════════════════════════════════════════════
           [10] BUTTONS — radius 8, teal primary
           ══════════════════════════════════════════════════════════════ */
        .btn {
            display: inline-flex; align-items: center; gap: 6px;
            padding: 8px 18px; border-radius: 8px !important;
            font-size: 13px; font-weight: 500; cursor: pointer;
            transition: all .15s; line-height: 1.4;
        }
        .btn:focus { box-shadow: 0 0 0 3px rgba(0,200,151,.18); }
        .btn-primary   { background: #00c897; border-color: #00c897; color: #fff !important; }
        .btn-primary:hover, .btn-primary:focus, .btn-primary:not(:disabled):active {
            background: #00b386; border-color: #00b386; color: #fff !important; }
        .btn-success   { background: #27ae60; border-color: #27ae60; color: #fff !important; }
        .btn-success:hover, .btn-success:focus { background: #219653; border-color: #219653; color: #fff !important; }
        .btn-danger    { background: #e74c3c; border-color: #e74c3c; color: #fff !important; }
        .btn-danger:hover, .btn-danger:focus  { background: #c0392b; border-color: #c0392b; color: #fff !important; }
        .btn-info      { background: #3a7bd5; border-color: #3a7bd5; color: #fff !important; }
        .btn-info:hover, .btn-info:focus      { background: #3268b8; border-color: #3268b8; color: #fff !important; }
        .btn-warning   { background: #e67e22; border-color: #e67e22; color: #fff !important; }
        .btn-warning:hover, .btn-warning:focus{ background: #cc6f1d; border-color: #cc6f1d; color: #fff !important; }
        .btn-secondary { background: #95a5a6; border-color: #95a5a6; color: #fff !important; }
        .btn-secondary:hover { background: #87999a; border-color: #87999a; color: #fff !important; }
        .btn-dark      { background: #1a1f36; border-color: #1a1f36; color: #fff !important; }
        .btn-default   { background: #fff; border: 1px solid #e0e4ef; color: #555 !important; }
        .btn-default:hover { background: #f5f5f5; color: #333 !important; }
        .btn-light     { background: #fff; border: 1px solid #e0e4ef; color: #555 !important; }
        .btn-light:hover { background: #f5f5f5; }
        .btn-outline-primary { color: #00a583 !important; border-color: #00c897; background: transparent; }
        .btn-outline-primary:hover { background: #00c897; color: #fff !important; }
        .btn-outline-secondary { color: #666 !important; border-color: #e0e4ef; }
        .btn-link { color: #00a583 !important; text-decoration: none; }
        .btn-sm { padding: 5px 12px; font-size: 12px; }
        .btn-xs, .btn.btn-xs { padding: 3px 10px !important; font-size: 11px !important; border-radius: 6px !important; }
        .btn-lg { padding: 10px 24px; font-size: 15px; }
        .btn-flat { border-radius: 8px !important; }
        .btn i { font-size: .9em; }
        .btn-group .btn { border-radius: 0; }
        .btn-group .btn:first-child { border-radius: 8px 0 0 8px; }
        .btn-group .btn:last-child  { border-radius: 0 8px 8px 0; }

        /* ══════════════════════════════════════════════════════════════
           [11] FORMS — uppercase labels, 1.5px borders, teal focus
           ══════════════════════════════════════════════════════════════ */
        label {
            display: inline-block; font-size: 12px; font-weight: 600; color: #555;
            text-transform: uppercase; letter-spacing: .4px; margin-bottom: 5px;
        }
        .form-group { margin-bottom: 14px; }
        .form-control, .custom-select {
            border: 1.5px solid #e0e4ef !important;
            border-radius: 8px !important;
            font-size: 13px !important; color: #333;
            padding: 8px 12px; height: auto;
            box-shadow: none !important;
            background-color: #fff;
            transition: border-color .2s, box-shadow .2s;
            font-family: inherit;
        }
        .form-control:focus, .custom-select:focus {
            border-color: #00c897 !important;
            box-shadow: 0 0 0 3px rgba(0,200,151,.12) !important;
        }
        .form-control.is-invalid, .custom-select.is-invalid { border-color: #e74c3c !important; }
        .form-control.is-valid   { border-color: #27ae60 !important; }
        .form-control:disabled, .form-control[readonly] { background: #f8f9fc !important; }
        .form-control-sm, .custom-select-sm { padding: 5px 10px; font-size: 12px !important; }
        .form-control-lg { padding: 10px 14px; font-size: 15px !important; }
        .invalid-feedback { font-size: 11px; color: #e74c3c; }
        .valid-feedback   { font-size: 11px; color: #27ae60; }
        .form-text { font-size: 12px; color: #888; }
        .form-check, .custom-control, .form-check-inline, .form-group .form-check {
            display: flex; align-items: center;
        }
        .form-check label, .form-check-inline label, .custom-control-label,
        .custom-checkbox label, .custom-radio label, .form-check .form-check-label {
            text-transform: none; font-weight: 400; color: #666; font-size: 13px;
            letter-spacing: 0; margin-bottom: 0;
        }
        .input-group-text {
            background: #f8f9fc !important; border: 1.5px solid #e0e4ef !important;
            color: #888 !important; font-size: 13px;
        }
        .input-group > .form-control:not(:first-child) { border-left: 0 !important; border-radius: 0 8px 8px 0 !important; }
        .input-group > .form-control:first-child { border-right: 0 !important; border-radius: 8px 0 0 8px !important; }
        .input-group-prepend .input-group-text { border-right: 0 !important; }
        .input-group-append .input-group-text { border-left: 0 !important; }
        .custom-file-label { border: 1.5px solid #e0e4ef; border-radius: 8px; font-size: 13px; }
        .custom-file-label::after {
            background: #f8f9fc; color: #555; border-left: 1.5px solid #e0e4ef;
            border-radius: 0 8px 8px 0; font-weight: 600; height: auto; line-height: 1.9;
        }
        input[type="checkbox"], input[type="radio"] { accent-color: #00c897; }

        /* Select2 — client-portal skin */
        .select2-container--default .select2-selection--single,
        .select2-container--default .select2-selection--multiple {
            border: 1.5px solid #e0e4ef !important;
            border-radius: 8px !important; padding: 3px 8px;
        }
        .select2-container--default .select2-selection--single { height: 38px; }
        .select2-container--default .select2-selection--single .select2-selection__rendered {
            font-size: 13px; color: #333; line-height: 30px;
        }
        .select2-container--default .select2-selection--single .select2-selection__arrow { height: 34px; }
        .select2-container--default.select2-container--focus .select2-selection--multiple,
        .select2-container--default .select2-selection--single:focus,
        .select2-container--default .select2-selection--multiple:focus { border-color: #00c897 !important; }
        .select2-container--default .select2-selection--multiple .select2-selection__choice {
            background: #e0faf3; border: 1px solid #b0e8d0; color: #1a7a50;
            border-radius: 999px; font-size: 12px; padding: 2px 10px;
        }
        .select2-container--default .select2-selection__choice__remove { color: #1a7a50; }
        .select2-container--default .select2-results__option--highlighted[aria-selected] {
            background: #00c897 !important; color: #fff;
        }
        .select2-dropdown { border: 1px solid #e0e4ef !important; border-radius: 8px !important; }
        .select2-container--open .select2-dropdown--above { border-radius: 0 0 8px 8px !important; }

        /* ══════════════════════════════════════════════════════════════
           [12] ALERTS + CALLOUTS — 4px left border style
           ══════════════════════════════════════════════════════════════ */
        .alert {
            padding: 14px 16px; border-radius: 8px; font-size: 13px;
            margin-bottom: 16px; display: flex; align-items: flex-start; gap: 10px;
        }
        .alert-dismissible { padding-right: 40px; }
        .alert-success { background: #f0fff8 !important; border: 1px solid #b0e8d0 !important; border-left: 4px solid #00c897 !important; color: #1a7a50 !important; }
        .alert-danger  { background: #fff0f0 !important; border: 1px solid #ffd0d0 !important; border-left: 4px solid #e74c3c !important; color: #c0392b !important; }
        .alert-warning { background: #fffbf0 !important; border: 1px solid #ffe0a0 !important; border-left: 4px solid #f39c12 !important; color: #b8860b !important; }
        .alert-info    { background: #eff5ff !important; border: 1px solid #cfe3fb !important; border-left: 4px solid #3a7bd5 !important; color: #2a5fa8 !important; }
        .alert i { margin-top: 1px; flex-shrink: 0; }
        .alert .btn-paynow {
            margin-left: auto; background: #e74c3c; color: #fff; border: none;
            border-radius: 6px; padding: 5px 14px; font-size: 12px; font-weight: 600;
            cursor: pointer; white-space: nowrap; text-decoration: none;
        }
        .callout {
            border-radius: 8px; border: 1px solid #eef0f5; border-left: 4px solid #00c897;
            background: #f0faf7; padding: 14px 16px; font-size: 13px; margin-bottom: 16px;
        }
        .callout.callout-danger  { background: #fff0f0; border-color: #ffd0d0; border-left-color: #e74c3c; color: #c0392b; }
        .callout.callout-warning { background: #fffbf0; border-color: #ffe0a0; border-left-color: #f39c12; color: #b8860b; }
        .callout.callout-info    { background: #eff5ff; border-color: #cfe3fb; border-left-color: #3a7bd5; color: #2a5fa8; }
        .callout.callout-success { background: #f0fff8; border-color: #b0e8d0; border-left-color: #00c897; color: #1a7a50; }
        .callout-title { font-size: 14px; font-weight: 600; }

        /* ══════════════════════════════════════════════════════════════
           [13] MODALS / DROPDOWNS / TOASTS
           ══════════════════════════════════════════════════════════════ */
        .modal-content {
            border-radius: 12px !important; border: 1px solid #eef0f5;
            box-shadow: 0 20px 60px rgba(0,0,0,.2);
        }
        .modal-header { padding: 14px 20px; border-bottom: 1px solid #f0f2f7; }
        .modal-header .close { padding: 8px; margin: -8px -8px -8px auto; outline: none; }
        .modal-title { font-size: 14px; font-weight: 600; color: #1a1f36; }
        .modal-body { padding: 20px; font-size: 13px; }
        .modal-footer { padding: 12px 20px; border-top: 1px solid #f0f2f7; }
        .modal-backdrop.show { opacity: .5; }

        .dropdown-menu {
            border-radius: 10px !important; border: 1px solid #eef0f5 !important;
            box-shadow: 0 8px 30px rgba(0,0,0,.12) !important;
            padding: 6px !important; font-size: 13px; z-index: 1055;
        }
        .dropdown-item { border-radius: 6px; padding: 8px 12px; color: #444; font-size: 13px; }
        .dropdown-item:hover, .dropdown-item:focus { background: #f0faf7; color: #00c897; }
        .dropdown-item i { color: #aaa; width: 16px; }
        .dropdown-item:hover i { color: #00c897; }
        .dropdown-divider { border-color: #f0f2f7; }
        .dropdown-header { font-size: 11px; text-transform: uppercase; letter-spacing: .5px; color: #aaa; font-weight: 600; }

        .toast { border: none; border-radius: 8px; overflow: hidden; font-size: 13px; }
        .toast-header { padding: 10px 14px; }

        /* ══════════════════════════════════════════════════════════════
           [14] PAGINATION / TABS / LIST GROUPS
           ══════════════════════════════════════════════════════════════ */
        .pagination { gap: 4px; flex-wrap: wrap; }
        .page-link {
            border: 1px solid #e0e4ef !important; color: #555 !important;
            border-radius: 6px !important; margin: 0 2px; font-size: 12px;
            padding: 5px 10px; line-height: 1.5;
        }
        .page-item.active .page-link {
            background: #00c897 !important; border-color: #00c897 !important; color: #fff !important;
        }
        .page-item.disabled .page-link { color: #bbb !important; background: #fafbfd !important; border-color: #f0f2f5 !important; }
        .page-item:first-child .page-link, .page-item:last-child .page-link { border-radius: 6px !important; }

        .nav-tabs { border-bottom: 1px solid #f0f2f7; }
        .nav-tabs .nav-link {
            border: none !important; color: #888 !important; font-size: 13px;
            font-weight: 500; padding: 10px 16px; background: transparent !important;
            border-radius: 8px 8px 0 0; margin-bottom: -1px;
        }
        .nav-tabs .nav-link:hover { color: #00c897 !important; }
        .nav-tabs .nav-link.active {
            color: #00c897 !important; font-weight: 600;
            border-bottom: 2px solid #00c897 !important; background: transparent !important;
        }
        .nav-pills .nav-link { color: #888; font-size: 13px; border-radius: 8px; padding: 7px 16px; }
        .nav-pills .nav-link.active { background: #00c897; color: #fff; font-weight: 600; }

        .list-group-item { border-color: #f4f6f9; font-size: 13px; padding: 12px 20px; }
        .list-group-item:hover { background: #fafbfd; }
        .list-group-item.active { background: #00c897; border-color: #00c897; }

        /* ══════════════════════════════════════════════════════════════
           [15] UTILITIES — client palette
           ══════════════════════════════════════════════════════════════ */
        .bg-primary   { background-color: #00c897 !important; }
        .bg-success   { background-color: #27ae60 !important; }
        .bg-info      { background-color: #3a7bd5 !important; }
        .bg-warning   { background-color: #f39c12 !important; }
        .bg-danger    { background-color: #e74c3c !important; }
        .bg-secondary { background-color: #95a5a6 !important; }
        .bg-teal      { background-color: #00c897 !important; }
        .bg-navy      { background-color: #1a1f36 !important; }
        .text-primary { color: #00a583 !important; }
        .border-primary { border-color: #00c897 !important; }

        /* SweetAlert compact skin (kept from old layout) */
        .swal-icon-sm { width: 30px !important; height: 30px !important; margin: .5rem auto !important; }
        .swal2-title { font-size: 1.1rem !important; padding: .5rem !important; }
        .swal2-html-container { font-size: .9rem !important; margin: .3rem !important; }

        /* ══════════════════════════════════════════════════════════════
           [16] RESPONSIVE — off-canvas sidebar + compact mobile
           ══════════════════════════════════════════════════════════════ */
        @media (max-width: 991.98px) {
            .a-hamburger { display: block; }
            .a-sidebar { transform: translateX(-100%); box-shadow: 0 0 40px rgba(0,0,0,.15); }
            .a-sidebar.open { transform: translateX(0); }
            .a-page-content { margin-left: 0; padding: 16px; }
            .a-footer { margin-left: 0; }
            body.a-sidebar-open { overflow: hidden; }
        }
        @media (max-width: 768px) {
            .a-page-title, .a-page-head h1 { font-size: 18px; }
            .a-page-head { flex-direction: column; align-items: stretch; }
            .a-page-actions { justify-content: flex-start; }
            .a-page-actions .btn { flex: 0 1 auto; }
            .a-brand { font-size: 16px; max-width: 46vw; }
            .cust-stat-card { min-height: 76px; padding: 14px 16px !important; }
            .cust-stat-card .sc-icon, .small-box > .icon, .info-box-icon { width: 44px; height: 44px; min-width: 44px; font-size: 17px !important; }
            .cust-stat-card .sc-value, .small-box .inner h3, .info-box-number { font-size: 20px !important; }
            .card-body { padding: 14px !important; }
            .card-header { padding: 12px 14px !important; }
            .table td, .table th { padding: 9px 10px; font-size: 12.5px; }
            .a-table-wrap .table { min-width: 640px; }
            .notif-dropdown { width: min(340px, calc(100vw - 32px)) !important; }
        }
        @media (max-width: 575.98px) {
            .a-user-pill .a-user-name { display: none; }
            .a-user-pill { padding: 5px; }
            .a-topbar { padding: 0 12px; }
            .a-brand { max-width: 40vw; }
            .cust-stat-card .sc-label { white-space: normal; }
        }

        /* ══════════════════════════════════════════════════════════════
           [17] RTL (Arabic) + PRINT
           ══════════════════════════════════════════════════════════════ */
        @if(app()->getLocale() === 'ar')
        body { direction: rtl; text-align: right; }
        .a-sidebar { left: auto; right: 0; border-right: none; border-left: 1px solid #e8eaf0; transform: none; }
        .a-nav-item, .a-sub-item { border-left: none; border-right: 3px solid transparent; }
        .a-nav-item.active, .a-sub-item.active { border-right-color: #00c897; }
        .a-page-content, .a-footer { margin-left: 0; margin-right: 200px; }
        @media (max-width: 991.98px) {
            .a-sidebar { transform: translateX(100%); }
            .a-sidebar.open { transform: translateX(0); }
            .a-page-content, .a-footer { margin-right: 0; }
        }
        @endif

        @media print {
            .a-topbar, .a-sidebar, .a-footer, .a-backdrop, .a-page-actions, .pagination, .btn { display: none !important; }
            .a-page-content { margin: 0 !important; padding: 0 !important; }
            body { background: #fff; }
        }
    </style>
</head>
<body>

{{-- ════════════════ TOPBAR ════════════════ --}}
<div class="a-topbar">
    <div class="a-topbar-left">
        <button class="a-hamburger" id="aHamburger" type="button" aria-label="Menu">
            <i class="fas fa-bars"></i>
        </button>
        <a href="{{ $homeUrl }}" class="a-brand">
            <div class="a-logo-box">{{ strtoupper(substr(trim($companyName), 0, 1)) }}</div>
            <span>{{ $companyName }}</span>
        </a>
    </div>
    <div class="a-topbar-right">
        @if($guard === 'web')
            @include('partials.language-switcher')
            @include('partials.notification-bell')
        @endif

        <div class="a-user-pill" id="aUserPill">
            <div class="a-user-avatar">{{ $initials }}</div>
            <span class="a-user-name">{{ $user->name ?? $user->email ?? 'Admin' }}</span>
            <i class="fas fa-chevron-down a-caret"></i>

            <div class="a-user-dropdown" id="aUserDropdown">
                <div class="a-dd-header">
                    <div class="a-dd-avatar">{{ $initials }}</div>
                    <div style="min-width:0;">
                        <div class="a-dd-name">{{ $user->name ?? $user->email ?? 'Admin' }}</div>
                        <div class="a-dd-sub">
                            @if($guard === 'super_admin')
                                Super Admin Panel
                            @elseif($user && method_exists($user, 'getRoleNames') && $user->getRoleNames()->count())
                                {{ ucfirst($user->getRoleNames()->first()) }}
                            @else
                                Admin / Staff Panel
                            @endif
                        </div>
                    </div>
                </div>
                @if($guard === 'web')
                    <div class="a-dd-divider"></div>
                    <a href="{{ route('profile.edit') }}" class="a-dd-item">
                        <i class="fas fa-user"></i> My Profile
                    </a>
                @endif
                <div class="a-dd-divider"></div>
                <form method="POST" action="{{ $guard === 'super_admin' ? route('super-admin.logout') : route('logout') }}">
                    @csrf
                    <button type="submit" class="a-dd-item a-dd-logout">
                        <i class="fas fa-sign-out-alt"></i> Logout
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

{{-- ════════════════ SIDEBAR ════════════════ --}}
<div class="a-sidebar" id="aSidebar">
    <nav class="a-side-nav">
        @include('layouts.partials._menu-items', ['items' => $menuItems])
    </nav>
    <div class="a-side-foot">
        <div class="a-nav-divider"></div>
        @if($guard === 'web')
            <a href="{{ route('profile.edit') }}" class="a-sub-item">
                <i class="fas fa-user-cog"></i> <span class="a-nav-text">Profile</span>
            </a>
        @endif
        <form method="POST" action="{{ $guard === 'super_admin' ? route('super-admin.logout') : route('logout') }}">
            @csrf
            <button type="submit" class="a-sub-item" style="width:100%; background:none; border:none; cursor:pointer; text-align:left; font-family:inherit; font-size:13px;">
                <i class="fas fa-sign-out-alt"></i> <span class="a-nav-text">Logout</span>
            </button>
        </form>
    </div>
</div>

{{-- Mobile backdrop --}}
<div class="a-backdrop" id="aBackdrop"></div>

{{-- ════════════════ MAIN ════════════════ --}}
<div class="a-main">
    <div class="a-page-content">

        {{-- Page heading: old content_header OR page_title/page_actions --}}
        <div class="a-page-head">
            @hasSection('content_header')
                @yield('content_header')
            @else
                <h1 class="a-page-title">@yield('page_title')</h1>
                <div class="a-page-actions">@yield('page_actions')</div>
            @endif
        </div>

        {{-- Global Toast Notification (same behaviour as before) --}}
        @if(session('success') || session('error') || session('warning'))
            @php
                $type    = session('success') ? 'success' : (session('error') ? 'error' : 'warning');
                $message = session('success') ?? session('error') ?? session('warning');
                $color   = $type === 'success' ? '#00c897' : ($type === 'error' ? '#e74c3c' : '#f39c12');
                $icon    = $type === 'success' ? 'check-circle' : ($type === 'error' ? 'times-circle' : 'exclamation-triangle');
                $title   = $type === 'success' ? 'Success' : 'Error';
            @endphp
            <div style="position:fixed; top:70px; right:20px; z-index:9999; min-width:300px; max-width:calc(100vw - 40px);">
                <div class="toast show" role="alert"
                     style="border:none; border-radius:8px; box-shadow:0 4px 15px rgba(0,0,0,0.15); overflow:hidden;">
                    <div class="toast-header" style="background:{{ $color }}; color:#fff; border:none;">
                        <i class="fas fa-{{ $icon }} mr-2"></i>
                        <strong class="mr-auto">{{ $title }}</strong>
                        <button type="button" class="ml-2 close" data-dismiss="toast" style="color:#fff; opacity:1;">&times;</button>
                    </div>
                    <div class="toast-body" style="background:#fff; font-size:14px; padding:12px 16px;">
                        {{ $message }}
                    </div>
                </div>
            </div>
        @endif

        {{-- Quick Add Category Modal (shared Income/Expense) --}}
        @if($guard === 'web')
            @include('accounting._quick_add_category_modal')
        @endif

        {{-- Main content: page_content (new style) OR content (legacy style) --}}
        @hasSection('page_content')
            @yield('page_content')
        @else
            @yield('content')
        @endif

    </div>

    {{-- Footer --}}
    <div class="a-footer">
        {{ date('Y') }} &copy; {{ $companyName }}
    </div>
</div>

{{-- ════════════════ SCRIPTS ════════════════ --}}
<script src="{{ asset('vendor/jquery/jquery.min.js') }}"></script>
<script src="{{ asset('vendor/bootstrap/js/bootstrap.bundle.min.js') }}"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

<script>
(function () {
    'use strict';

    /* ── 1. Sidebar (mobile) ─────────────────────────────── */
    var sidebar  = document.getElementById('aSidebar');
    var backdrop = document.getElementById('aBackdrop');
    var burger   = document.getElementById('aHamburger');

    function closeSidebar() {
        sidebar.classList.remove('open');
        backdrop.classList.remove('show');
        document.body.classList.remove('a-sidebar-open');
    }
    if (burger) burger.addEventListener('click', function (e) {
        e.stopPropagation();
        var open = sidebar.classList.toggle('open');
        backdrop.classList.toggle('show', open);
        document.body.classList.toggle('a-sidebar-open', open);
    });
    if (backdrop) backdrop.addEventListener('click', closeSidebar);
    document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape') { closeSidebar(); closeUserDropdown(); }
    });
    /* a nav link click should close the drawer on mobile */
    sidebar.addEventListener('click', function (e) {
        var link = e.target.closest('a');
        if (link && window.innerWidth <= 991.98) setTimeout(closeSidebar, 60);
    });

    /* ── 2. Submenu accordion ────────────────────────────── */
    document.querySelectorAll('.a-group-toggle').forEach(function (btn) {
        btn.addEventListener('click', function () {
            var group = btn.closest('.a-nav-group');
            var willOpen = !group.classList.contains('open');
            /* close sibling groups on the same level (accordion) */
            if (willOpen) {
                var parent = group.parentElement.closest('.a-submenu-inner, .a-side-nav');
                if (parent) parent.querySelectorAll(':scope > .a-nav-group.open').forEach(function (g) {
                    if (g !== group) g.classList.remove('open');
                });
            }
            group.classList.toggle('open', willOpen);
        });
    });

    /* ── 3. User dropdown ────────────────────────────────── */
    var userPill    = document.getElementById('aUserPill');
    var userDrop    = document.getElementById('aUserDropdown');
    function closeUserDropdown() { if (userDrop) userDrop.classList.remove('open'); }
    if (userPill) userPill.addEventListener('click', function (e) {
        e.stopPropagation();
        userDrop.classList.toggle('open');
    });
    document.addEventListener('click', function () { closeUserDropdown(); });

    /* ── 4. AdminLTE card collapse shim ──────────────────── */
    document.querySelectorAll('[data-card-widget="collapse"]').forEach(function (btn) {
        btn.addEventListener('click', function (e) {
            e.preventDefault();
            var card = btn.closest('.card');
            if (!card) return;
            card.querySelectorAll(':scope > .card-body, :scope > .card-footer').forEach(function (el) {
                el.style.display = (el.style.display === 'none') ? '' : 'none';
            });
            var icon = btn.querySelector('i');
            if (icon) {
                if (icon.classList.contains('fa-minus'))      { icon.classList.remove('fa-minus');  icon.classList.add('fa-plus'); }
                else if (icon.classList.contains('fa-plus'))  { icon.classList.remove('fa-plus');   icon.classList.add('fa-minus'); }
            }
        });
    });

    /* ── 5. Wrap tables for horizontal scroll on mobile ──── */
    document.querySelectorAll('.card table, .a-page-content > table').forEach(function (t) {
        if (t.closest('.table-responsive') || t.closest('.a-table-wrap')) return;
        var wrap = document.createElement('div');
        wrap.className = 'a-table-wrap';
        t.parentNode.insertBefore(wrap, t);
        wrap.appendChild(t);
    });

    /* ── 6. Stat-card beautifier: solid color → white card + icon chip ── */
    var CHIP_BY_HEX = {
        '17a2b8':'blue','3c8dbc':'blue','2980b9':'blue','3498db':'blue','007bff':'blue','0d6efd':'blue','00a8dc':'blue','5bc0de':'blue',
        '00a65a':'green','28a745':'green','2ecc71':'green','27ae60':'green','00c853':'green','218838':'green',
        '1abc9c':'teal','16a085':'teal','00c897':'teal','20c997':'teal',
        'f39c12':'orange','e67e22':'orange','d35400':'orange','f5b041':'orange','ffc107':'orange','fd7e14':'orange',
        'dd4b39':'red','e74c3c':'red','c0392b':'red','dc3545':'red','b71c1c':'red',
        '9b59b6':'purple','8e44ad':'purple','6f42c1':'purple','605ca8':'purple','6610f2':'purple',
        '6c757d':'gray','7f8c8d':'gray','95a5a6':'gray','adb5bd':'gray','343a40':'gray'
    };
    var CHIP_BY_CLASS = {
        'bg-primary':'blue','bg-success':'green','bg-info':'teal','bg-warning':'orange',
        'bg-danger':'red','bg-secondary':'gray','bg-purple':'purple','bg-teal':'teal',
        'bg-navy':'blue','bg-indigo':'purple','bg-pink':'red','bg-cyan':'teal','bg-gray':'gray','bg-dark':'gray'
    };
    function rgbToHex(c) {
        var m = c.match(/rgba?\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)/i);
        if (!m) return null;
        return ((1 << 24) + (parseInt(m[1]) << 16) + (parseInt(m[2]) << 8) + parseInt(m[3])).toString(16).slice(1);
    }
    function hueChip(hex) {
        try {
            var r = parseInt(hex.substr(0,2),16), g = parseInt(hex.substr(2,2),16), b = parseInt(hex.substr(4,2),16);
            var max = Math.max(r,g,b), min = Math.min(r,g,b);
            if (max === min) return 'gray';
            if (max === r) return (g > r * 0.62) ? 'orange' : 'red';
            if (max === g) return (b > (r + g) / 3) ? 'teal' : 'green';
            return 'blue';
        } catch (e) { return 'teal'; }
    }
    function detectChip(el, styleAttr) {
        var m = (styleAttr || el.getAttribute('style') || '').match(/#([0-9a-f]{6})/i);
        if (m && CHIP_BY_HEX[m[1].toLowerCase()]) return CHIP_BY_HEX[m[1].toLowerCase()];
        var rgb = el.style && el.style.backgroundColor ? rgbToHex(el.style.backgroundColor) : null;
        if (rgb) return CHIP_BY_HEX[rgb] || hueChip(rgb);
        var cls = el.className || '';
        for (var k in CHIP_BY_CLASS) { if (cls.indexOf(k) !== -1) return CHIP_BY_CLASS[k]; }
        return null;
    }
    function stripBg(el) {
        if (el.style) { el.style.background = ''; el.style.backgroundColor = ''; }
        (el.className.match(/bg-[a-z]+/g) || []).forEach(function (c) {
            if (c !== 'bg-white') el.classList.remove(c);
        });
    }
    /* .cust-stat-card */
    document.querySelectorAll('.cust-stat-card').forEach(function (card) {
        var chip = detectChip(card) || 'teal';
        stripBg(card);
        card.classList.add('sc', 'sc-' + chip);
    });
    /* .small-box */
    document.querySelectorAll('.small-box').forEach(function (box) {
        var chip = detectChip(box) || 'teal';
        stripBg(box);
        box.classList.add('sb-' + chip);
    });
    /* .info-box → chip on the icon */
    document.querySelectorAll('.info-box').forEach(function (box) {
        var icon = box.querySelector('.info-box-icon');
        var chip = detectChip(icon || box) || 'teal';
        if (icon) stripBg(icon);
        box.classList.add('ib-' + chip);
    });

    /* ── 7. Bootstrap tooltips ───────────────────────────── */
    if (window.jQuery) {
        jQuery(function () {
            jQuery('[data-toggle="tooltip"]').tooltip();
        });
    }
})();

/* ── 8. Global toast auto-hide (jQuery) ─────────────────── */
if (window.jQuery) {
    jQuery(function () {
        setTimeout(function () {
            jQuery('.toast').fadeOut(500, function () { jQuery(this).remove(); });
        }, 4000);

        /* ── 9. Global SweetAlert delete confirm ─────────── */
        document.querySelectorAll('.swal-delete').forEach(function (btn) {
            btn.addEventListener('click', function (e) {
                e.preventDefault();
                var form = btn.closest('form');
                var msg  = btn.getAttribute('data-message') || 'Are you sure?';
                Swal.fire({
                    title: 'Are you sure?',
                    text: msg,
                    showCancelButton: true,
                    confirmButtonColor: '#e74c3c',
                    cancelButtonColor: '#95a5a6',
                    confirmButtonText: 'Yes, Delete',
                    cancelButtonText: 'Cancel',
                    width: '350px'
                }).then(function (result) {
                    if (result.isConfirmed && form) form.submit();
                });
            });
        });
    });
}
</script>

@yield('extra_js')
@yield('js')
@stack('js')
</body>
</html>
