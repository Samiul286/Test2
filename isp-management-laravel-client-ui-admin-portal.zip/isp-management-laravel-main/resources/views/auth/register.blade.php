{{-- resources/views/auth/register.blade.php --}}
@extends('layouts.auth')

@section('title', 'Register')
@section('auth_subtitle', 'Create New Account')

@section('content')
    <form method="POST" action="{{ route('register') }}">
        @csrf

        <div class="form-group">
            <label>Full Name</label>
            <div class="input-wrap">
                <i class="fas fa-user"></i>
                <input type="text" name="name"
                    class="form-control {{ $errors->has('name') ? 'is-invalid' : '' }}"
                    placeholder="Your full name"
                    value="{{ old('name') }}"
                    autocomplete="name" autofocus required>
            </div>
            @error('name')
                <div class="invalid-feedback">{{ $message }}</div>
            @enderror
        </div>

        <div class="form-group">
            <label>Email Address</label>
            <div class="input-wrap">
                <i class="fas fa-envelope"></i>
                <input type="email" name="email"
                    class="form-control {{ $errors->has('email') ? 'is-invalid' : '' }}"
                    placeholder="you@example.com"
                    value="{{ old('email') }}"
                    autocomplete="email" required>
            </div>
            @error('email')
                <div class="invalid-feedback">{{ $message }}</div>
            @enderror
        </div>

        <div class="form-group">
            <label>Password</label>
            <div class="input-wrap">
                <i class="fas fa-lock"></i>
                <input type="password" name="password"
                    class="form-control {{ $errors->has('password') ? 'is-invalid' : '' }}"
                    placeholder="Choose a password"
                    autocomplete="new-password" required>
            </div>
            @error('password')
                <div class="invalid-feedback">{{ $message }}</div>
            @enderror
        </div>

        <div class="form-group">
            <label>Confirm Password</label>
            <div class="input-wrap">
                <i class="fas fa-lock"></i>
                <input type="password" name="password_confirmation"
                    class="form-control"
                    placeholder="Repeat password"
                    autocomplete="new-password" required>
            </div>
        </div>

        <button type="submit" class="btn-login">
            <i class="fas fa-user-plus"></i> Register
        </button>
    </form>

    <div class="auth-links">
        Already have an account? <a href="{{ route('login') }}">Log in</a>
    </div>
@endsection
