{{-- resources/views/auth/verify-email.blade.php --}}
@extends('layouts.auth')

@section('title', 'Verify Email')
@section('auth_subtitle', 'Email Verification')

@section('content')
    <p style="font-size:13px; color:#666; margin-bottom:1.25rem;">
        Thanks for signing up! Before getting started, could you verify your email address
        by clicking on the link we just emailed to you? If you didn't receive the email,
        we will gladly send you another.
    </p>

    <form method="POST" action="{{ route('verification.send') }}">
        @csrf
        <button type="submit" class="btn-login">
            <i class="fas fa-paper-plane"></i> Resend Verification Email
        </button>
    </form>

    <div class="auth-links">
        <a href="{{ route('logout') }}" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">Log Out</a>
        <form id="logout-form" method="POST" action="{{ route('logout') }}" style="display:none;">@csrf</form>
    </div>
@endsection
