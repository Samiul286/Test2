{{-- resources/views/auth/passwords/confirm.blade.php --}}
@extends('layouts.auth')

@section('title', 'Confirm Password')
@section('auth_subtitle', 'Secure Area')

@section('content')
    <p style="font-size:13px; color:#666; margin-bottom:1.25rem;">
        This is a secure area of the application. Please confirm your password before continuing.
    </p>

    <form method="POST" action="{{ route('password.confirm') }}">
        @csrf

        <div class="form-group">
            <label>Password</label>
            <div class="input-wrap">
                <i class="fas fa-lock"></i>
                <input type="password" name="password"
                    class="form-control {{ $errors->has('password') ? 'is-invalid' : '' }}"
                    placeholder="Your password"
                    autocomplete="current-password" autofocus required>
            </div>
            @error('password')
                <div class="invalid-feedback">{{ $message }}</div>
            @enderror
        </div>

        <button type="submit" class="btn-login">
            <i class="fas fa-shield-alt"></i> Confirm
        </button>
    </form>
@endsection
