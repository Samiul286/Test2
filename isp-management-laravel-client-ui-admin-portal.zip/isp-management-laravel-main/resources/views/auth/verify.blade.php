{{-- resources/views/auth/verify.blade.php --}}
{{-- Legacy alias of verify-email, kept for any stray references --}}
@extends('auth.verify-email')
