{{-- resources/views/auth/forgot-password.blade.php --}}
@extends('layouts.auth')

@section('title', 'Forgot Password')
@section('auth_subtitle', 'Password Recovery')

@section('content')
    <p style="font-size:13px; color:#666; margin-bottom:1.25rem;">
        Forgot your password? No problem. Just let us know your email address and
        we will email you a password reset link that will allow you to choose a new one.
    </p>

    <form method="POST" action="{{ route('password.email') }}">
        @csrf

        <div class="form-group">
            <label>Email Address</label>
            <div class="input-wrap">
                <i class="fas fa-envelope"></i>
                <input type="email" name="email"
                    class="form-control {{ $errors->has('email') ? 'is-invalid' : '' }}"
                    placeholder="admin@example.com"
                    value="{{ old('email') }}"
                    autocomplete="email" autofocus required>
            </div>
            @error('email')
                <div class="invalid-feedback">{{ $message }}</div>
            @enderror
        </div>

        <button type="submit" class="btn-login">
            <i class="fas fa-paper-plane"></i> Send Reset Link
        </button>
    </form>

    <div class="auth-links">
        <a href="{{ route('login') }}"><i class="fas fa-arrow-left"></i> Back to login</a>
    </div>
@endsection
